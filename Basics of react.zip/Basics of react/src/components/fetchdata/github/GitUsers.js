import React from 'react'

const GitUsers = () => {
  return (
    <div>GitUsers</div>
  )
}

export default GitUsers