import React from 'react'

const Loading = () => {
  return (
    <div>L</div>
  )
}

export default Loading 