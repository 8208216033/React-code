export const UserData=[
    {
        id:1,
        name:"Lenne Gram",
        username:"Bret"
    },
    {
        id:2,
        name:"Ervin Howell",
        username:"Antora"
    },
    {
        id:3,
        name:"Smak Henny",
        username:"Radoo"
    },
    {
        id:4,
        name:"Michel Gram",
        username:"Mac"
    },

]