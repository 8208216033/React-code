 import React from 'react';
 import {productSearch} from '../redux/productAction'
 import './header.css';
 import { useDispatch } from 'react-redux';
 import {Link} from 'react-router-dom'
// import {useSelector} from 'react-redux'
// const Header = () => {
//     const result=useSelector((state)=>state)
//     console.log("redux data",result)
//     return (
//     <div className='header'>
//      <div className='cart-div'>
//         <span> cart 0</span>
//      </div>

//     </div>
//   )
// }

// export default Header

import {useSelector} from 'react-redux'

const Header =()=>{
    const result = useSelector((state)=>state.cartData);
    //console.warn("data in header", result);
    const dispatch=useDispatch();

    return(
        <div className="header">
             <div className='search'>
            <input type="text" onClick={(e)=>dispatch(productSearch(e.target.value))} placeholder="search"/>
           </div>
            <Link to='/cart'>
           
            <div className="cart-div">
                <span>{result.length}</span>
                <img src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt=""/>
            </div>
            </Link>
        </div>
    )
}

export default Header;