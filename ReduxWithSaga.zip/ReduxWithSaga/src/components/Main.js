import React, { useEffect } from "react";
import Header from "./Header";
import { addToCart, emptyCart, removeFromCart } from "../redux/action";
import { useDispatch, useSelector } from "react-redux";
import { productList } from "../redux/productAction";
import './main.css'
const Main = () => {
  const dispatch = useDispatch();
  let data = useSelector((state) => state.productData);
  // console.log("Data from main component", data);
  // const product = {
  //   name: "phone",
  //   type: "mobile",
  //   price: 89,
  //   color: "red",
  // };
  useEffect(()=>
  {
    dispatch(productList())
  },[])
  return (
     <>
       {/* <Header /> */}
      {/* <div>
        <button onClick={() => dispatch(addToCart(product))}>
          Add to cart
        </button>
      </div> */}
      {/* <div>
        <button onClick={() => dispatch(removeFromCart(product.name))}>
          Remove from cart
        </button>
      </div> */}
      {/* <div>
        <button onClick={() => dispatch(emptyCart())}>Empty cart</button>
      </div> */}

      {/* <div>
        <button onClick={() => dispatch(productList())}>Product list</button>
      </div> */}

      <div className="product-container">
        {
         data.map((item)=><div key={item.id} className="product-item">
         
          <img className="img" src={item.image}/>
           <div>{item.name}</div>
           <div>{item.color}</div>
           <div>{item.brand}</div>
           <div>{item.price}</div>
           
           <div className="btn">
            <button onClick={() => dispatch(addToCart(item))} className=" add">ADD TO CART</button>
            <button onClick={() => dispatch(removeFromCart(item.id))} className=" remove">REMOVE TO CART</button>
            </div>
          </div>)
        }
      </div>
    </>
  );
};

export default Main;
