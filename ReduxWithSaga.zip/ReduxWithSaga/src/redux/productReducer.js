import { PRODUCT_LIST,SET_PRODUCT_LIST} from "./constant";
export const productData = (data = [], action) => {
  
  
    // if (action.type === ADD_TO_CART) {
    // console.warn("ADD_TO_CART condtion ", action)

    //     // some logic
    //     return data
    // } else {
    //     return "no action called"
    // }

    switch(action.type){
        // case PRODUCT_LIST:
        //     console.log("PRODUCT_LIST",action)
        //     return [action.data];

            case SET_PRODUCT_LIST:
                console.log("PRODUCT_LIST",action.data)
                return [...action.data];
           
                default:
                return data;
    }
}