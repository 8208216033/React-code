import { PRODUCT_LIST, SET_PRODUCT_LIST,SEARCH_PRODUCT} from "./constant"

export const productList = () => {
    // let data= await fetch("https://jsonplaceholder.typicode.com/todos/1");
    // data=await data.json();
    //console.warn("action is called", data)
    return {
        type: PRODUCT_LIST,
        //data:"abc"
    }
}

// export const setProductList = (data) => {
//     console.log("set action called",data);
//     return {
       
//         type: SET_PRODUCT_LIST,
//         data:data
//     }
// }

export const productSearch = (query) => {
    
    return {
        type: SEARCH_PRODUCT,
        query
        //data:"abc"
    }
}