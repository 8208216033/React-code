import React from 'react'
import {addToCart} from './redux/action'
import { useDispatch } from 'react-redux'
import Header from './components/Header';
import Main from './components/Main';
import {Routes,Route} from 'react-router-dom';
import Cart from './components/Cart';

const App = () => {

  return (
    <>
    {/* <Header/>
     <Main/> */}
     <Header/>
     <Routes>
     <Route exact path="/" element={<Main/>}/>
     <Route exact path="/cart" element={<Cart/>}/>

     </Routes>
    </>
  )
}

export default App