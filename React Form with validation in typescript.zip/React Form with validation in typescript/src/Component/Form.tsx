import React, { useState } from 'react'
import './form.css'
import {Ivalues} from '../interfaces'
const defaultValues={
    name:'',
    // username:'',
    email:'',
    password:'',
    confirmPassword:'',
    phone:'',
    check:false,
    status:'',
    errors:{
        name:'',
        // username:'',
        email:'',
        password:'',
        phone:'',
        confirmPassword:'',
        checkbox:'',
        status:''

    }

}


const Form = () => {
    
    const [form,setForm]=useState<Ivalues>(defaultValues)
    
    const validEmailRegex = RegExp(
        /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
      );

      const validPhoneRegex=RegExp(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im
      );

      const validPasswordRegex=RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})")
    const handleChangename=(e:any)=>{
     e.preventDefault();
    //  const {name,value}=e.target;
    setForm({...form,name:e.target.value})
    const {name,value}=e.target; 
    switch(name){
        case 'name':
            form.errors.name=value.length<4?'full name must be atleast 4 characters':''
            console.log("........",form.errors.name)
            break;
            case 'email': 
        form.errors.email = 
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
        break;
        default:
            break;
     }
    }
    
    //const errors=form.errors
    const validate=(errors:Object)=>
    { 
        let valid=true
        Object.values(errors).forEach(val=>val.length>0&&(valid=false));
        return valid;
    }
   
   const handleChangeemail=(e:any)=>
   {
    setForm({...form,email:e.target.value});
    const {email,value}=e.target;
    form.errors.email = 
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
   }
//    const phoneValidation=()=> {
//     const regex = /^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$/i;
//     return !(!form.phone || regex.test(form.phone) === false);
//   }
   const handleChangephone=(e:any)=>{
    setForm({...form,phone:e.target.value});
    
    const{phone,value}=e.target;
    form.errors.phone=validPhoneRegex.test(value)?'':'phone number is not valid'
   }

   const handleChangepassword=(e:any)=>{
    setForm({...form,password:e.target.value})
    const {password,value}=e.target;
    form.errors.password=validPasswordRegex.test(value)?'':'password must contain minimum 8 with combination of Special characters,numbers,Uppercase letters and lowercase letters'
   }

   const handleChangeConfirmPassword=(e:any)=>{
    setForm({...form,confirmPassword:e.target.value});
    const {confirmPassword,value}=e.target;
    form.errors.confirmPassword=form.password!==value?'password not match':'';
   }

   const handleCheck=(e:any)=>
   {
    setForm({...form,check:!form.check});
   const {check}=e.target;
    form.errors.checkbox=form.check!=true?'':'check required';
   }

   const handleRadio=(e:any)=>
   {
    setForm({...form,status:e.target.value})
    const {staus,value}=e.target;
    form.errors.status=!value?'please select one':""
   }
    const handleSubmit=(e:any)=>{
        e.preventDefault();
        console.log(form);
        if(validate(form.errors)){
           alert('valid form details')
        }
    }
    return (
   <>
   <div className='wrapper'>
   <div className='form-wrapper'>
  
   <form onSubmit={handleSubmit}>
   <div className='fullName'>
   <label htmlFor="fullName"> Name</label><input type="text" name='name' value={form.name} onChange={handleChangename}/>
  {form.errors.name.length>0 && <span className='error'>{form.errors.name}</span>}
</div>
<div className='email'>
              <label htmlFor="email">Email</label>
   <input type="email" name="email" value={form.email} onChange={handleChangeemail}/>
  {form.errors.email.length>0 && <span className='error'>{form.errors.email}</span>}
</div>
<div className='email'>
              <label htmlFor="email">Phone Number</label>
 <input type="phone" name="phone" value={form.phone} onChange={handleChangephone}/>
  {form.errors.phone.length>0 && <span>{form.errors.phone}</span>}
  </div>
  <div className='password'>
              <label htmlFor="password">Password</label>
  <input type="text" name="password" value={form.password} onChange={handleChangepassword}/>
  {form.errors.password.length>0 && <span className='error'>{form.errors.password}</span>}
  </div>
  <div className='password'>
              <label htmlFor="password">Confirm Password</label>
  <input type="text" name="confirmPassword" value={form.confirmPassword} onChange={handleChangeConfirmPassword}/>
  {form.errors.confirmPassword.length>0 && <span className='error'>{form.errors.confirmPassword}</span>}
  </div>
  <div className='password'>
              <label htmlFor="password">Accept terms</label>
 <input type="checkbox" name="check" defaultChecked={form.check} onChange={handleCheck}/>
  {form.errors.checkbox.length>0 && <span className='error'>{form.errors.checkbox}</span>}
</div>
<div className='password'>
              

  
  <div>
  <label htmlFor="password">Gender</label>:
              <label htmlFor="password">Male</label>

    <input type="radio" value="male" name="gender" onChange={handleRadio}/>
  <label htmlFor="password">Female</label>

  <input type="radio" value="female" name="gender"  onChange={handleRadio}/>
  {form.errors.status.length>0 && <span className='error'>{form.errors.status}</span>}
  </div>
  </div>
   <button>Submit</button>
   </form>
   </div>
   </div>
   </>
  )
}

export default Form