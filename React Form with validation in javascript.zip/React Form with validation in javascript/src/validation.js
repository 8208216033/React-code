import React from 'react'

const validation = () => {
  return (
    <div>validation</div>
  )
}

export default validation